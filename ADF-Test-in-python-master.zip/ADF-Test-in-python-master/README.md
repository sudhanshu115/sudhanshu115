# ADF-Test-in-python
ADF test in python to check the stationarity for a particular data set
